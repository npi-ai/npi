from npiai.app.github.app import GitHub

__all__ = ['GitHub']
