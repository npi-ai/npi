from npiai.app.slack.app import Slack

__all__ = ['Slack']
